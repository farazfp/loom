# Original Poem Details
- Title: {{title}}
- Translation: [[]] 
- Author: Author Name
- Date (if known): Original Date


# Poem Content
[Original Persian poem goes here...]

# Context/Notes
## Historical Context
[Historical context of the poem]

## Linguistic Notes
[Linguistic notes]

## Cultural References
[Cultural references or significance]

# References
[External resources or publications related to the poem]
