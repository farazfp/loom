---
date: "{{DATE}}"
draft: "false"
tags:
---
 
The rest of your content lives here. You can use **Markdown** here :)
# Poet Details
- Name: Poet's Full Name
- Date of Birth: DOB
- Date of Death: DOD (if applicable)


# Poet's Biography
[A brief bio or overview of the poet's life, works, significance, etc.]

# Associated Poems
[Links to poems by this poet you've worked on or referenced]

# Notable Works or Contributions
[List of notable works or contributions]

# References
[External resources, publications, or any other relevant materials related to the poet]
