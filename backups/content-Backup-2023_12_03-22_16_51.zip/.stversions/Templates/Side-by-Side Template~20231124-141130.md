---
date: "{{today}}"
draft: "false"
tags:
---


- En-Fa 

Original: [[]]
Translation: [[]]