[[4. Do you believe divine grace in you does not dwell - It does]]
[[6 - My dear I'll never let my heart and your love be apart]]
