![[Shafi'i 1.png]]
