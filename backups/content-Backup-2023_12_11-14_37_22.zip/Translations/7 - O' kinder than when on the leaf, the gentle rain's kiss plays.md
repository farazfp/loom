# Translation Details
- Translated on: 2023-12-11    
- Side by Side: [[7 - O' kinder than when on the leaf, the gentle rain's kiss plays - En-Fa]]  
- Poet:  [[Shafi'i Kadekani]] 

![[7 - O' kinder than when on the leaf, the gentle rain's kiss plays,.png]]


O' kinder than when on the leaf, the gentle rain's kiss plays,  
Awakening of stars under the brooklet's tender gaze  

The mirror of your eye is where the dawn and ocean meet,  
Your rare smile is a dawn aglow, where bright stars are replete.  

Come back, for your absence raises my silent, maddened cries,  
and from the rocks of mountainscapes their mournful echo flies.  

O flowing brook, beneath this shelt'ring leafy shade remain,  
For countless souls have let such chances slip away in vain.  

You spoke of days when love had taken root, and I replied  
Though time may march and ages turn, that love will still abide.  

Estrangement is beyond what we can bear, dear one, don't shun,  
This lover, burdened with regret, leading those come undone.  

Before we came, a multitude have lived and left their trace,  
On life's grand wall, a chronicle that time cannot erase.  

After us, this love's melody shall evermore remain,  
As long as will exist the timeless song of wind and rain.  

# Translator's Notes
[Notes on the challenges faced, decisions made, or insights during the translation process]

# Revision History
- Date: [Date of revision], Changes: [Description of changes]

# Feedback
[Feedback received and actions taken]

