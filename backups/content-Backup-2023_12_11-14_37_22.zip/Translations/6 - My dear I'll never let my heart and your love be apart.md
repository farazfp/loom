# Translation Details
- Translated on: 2023-12-10  
- Side by Side: [[6 - My dear I'll never let my heart and your love be apart - En-Fa]]  
- Poet: [[Sana’i Ghaznavi]]  
-
![[6 - My dear I'll never let my heart and your love be apart.png]]


My dear, I'll never let my heart and your love be apart,  
I am your captive, though I'm free - forever bound at heart.  

From time eternal, your love and my soul have been entwined,  
No salvation from loving you in this life will I find.  

From all but you, my heart and soul, I've cleansed away desire,  
And like a censer full of flame, your love fills me with fire.  

Over this world and after, to your love my heart is bound  
Upon this path toward you, I cast my pride on the ground.  

Since I have seen your smile, like pearls in laughter's bright array,  
My eyes, like jeweled streams, are weeping rubies night and day.  

Since grief for you, like armies fierce, has seized my heart and mind,  
Prudence and reputation to the winds I have resigned.  


# Translator's Notes
[Notes on the challenges faced, decisions made, or insights during the translation process]

# Revision History
- Date: [Date of revision], Changes: [Description of changes]

# Feedback
[Feedback received and actions taken]

