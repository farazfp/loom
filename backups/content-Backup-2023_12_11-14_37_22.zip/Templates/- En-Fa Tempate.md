
Translation:  
Poet: 
