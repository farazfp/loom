
Translation:  [[6 - My dear I'll never let my heart and your love be apart]]  
Poet: [[Sana’i Ghaznavi]]


| English Translation | Original Persian |
|---------------------|------------------|
| My dear, I'll never let my heart and your love be apart,| برندارم دل ز مهرت دلبرا تا زنده‌ام |
| I am your captive, though I'm free - forever bound at heart.  | ور چه آزادم ترا تا زنده‌ام من بنده‌ام |
| From time eternal, your love and my soul have been entwined,| مهر تو با جان من پیوسته گشت اندر ازل |
| No salvation from loving you in this life will I find. | نیست روی رستگاری زو مرا تا زنده‌ام |
| From all but you, my heart and soul, I've cleansed away desire, | از هوای هر که جز تو جان و دل بزدوده‌ام |
| And like a censer full of flame, your love fills me with fire. | وز وفای تو چو نار از ناردان آگنده‌ام |
| Over this world and after, to your love my heart is bound | عشق تو بر دین و دنیا دلبرا بگزیده‌ام |
 |Upon this path toward you, I cast my pride on the ground | خواجگی در راه تو در خاک راه افگنده‌ام |
| Since I have seen your smile, like pearls in laughter's bright array, | تا بدیدم درج مروارید خندان ترا |
| My eyes, like jeweled streams, are weeping rubies night and day. | بس عقیقا کز دریغ از دیده بپراکنده‌ام |
| Since grief for you, like armies fierce, has seized my heart and mind, | تا به من بر لشگر اندوه تو بگشاد دست |
| Prudence and reputation to the winds I have resigned. | از صلاح و نیکنامی دستها بفشانده‌ام |

