Translation:  [[7 - O' kinder than when on the leaf, the gentle rain's kiss plays]]
Poet: [[Shafi'i Kadekani]]

| English Translation                         |  Original Persian                          |
|--------------------------------------------------------------|-------------------------------------------|
| O kinder than when on the leaf, the gentle rain's kiss plays, | ای مهربان تر از برگ در بوسه‌های باران    |
| Awakening of stars under the brooklet's tender gaze            | بیداری ستاره در چشم جویباران             |
| The mirror of your eye is where the dawn and ocean meet,      | آیینه ی نگاهت پیوند صبح و ساحل           |
| Your rare smile is a dawn aglow, where bright stars are replete.| لبخند گاه گاهت صبح ستاره باران         |
| Come back, for your absence raises my silent, maddened cries,   | بازآ که در هوایت خاموشی جنونم           |
| and from the rocks of mountainscapes their mournful echo flies. | فریاد ها برانگیخت از سنگ کوه ساران      |
| O flowing brook, beneath this sheltering leafy shade remain,   | ای جویبار جاری ! زین سایه برگ مگریز     |
| For countless souls have let such chances slip away in vain.    | کاین گونه فرصت از کف دادند بی شماران    |
| You spoke of days when love had taken root, and I replied       | گفتی : به روزگاران مهری نشسته گفتم     |
| Though time may march and ages turn, that love will still abide.| بیرون نمی توان کرد حتی به روزگاران     |
| Estrangement is beyond what we can bear, dear one, don't shun,  | بیگانگی ز حد رفت ای آشنا مپرهیز       |
| This lover, burdened with regret, leading those come undone.    | زین عاشق پشیمان سرخیل شرمساران         |
| Before we came, a multitude have lived and left their trace, | پیش از من و تو بسیار بودند و نقش بستند |
| On life's grand wall, a chronicle that time cannot erase.       | دیوار زندگی را زین گونه یادگاران      |
| After us, this love's melody shall evermore remain,             | وین نغمه ی محبت بعد از من و تو ماند     |
| As long as will exist the timeless song of wind and rain.          | تا در زمانه باقی ست آواز باد و باران    |

<iframe title="shajarian - boosehaaye baaraan" src="https://www.youtube.com/embed/loXG1Y41oF8?feature=oembed" height="150" width="200" style="aspect-ratio: 1.33333 / 1; width: 100%; height: 100%;" allowfullscreen="" allow="fullscreen"></iframe>
