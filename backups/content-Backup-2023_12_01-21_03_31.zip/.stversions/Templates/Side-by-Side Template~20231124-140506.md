---
date: "{{today}}"
draft: false
tags:
  - example-tag
---
 
The rest of your content lives here. You can use **Markdown** here :)

- En-Fa 

Original: [[]]
Translation: [[]]